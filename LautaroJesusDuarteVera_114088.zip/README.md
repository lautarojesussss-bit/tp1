<div align="right">
    <img width="32px" src="img/algo2.svg">
</div>

# TP


## Información del estudiante

* Lautaro Jesús Duarte Vera
* 114088
* lautarojesussss@gmail.com

---

## Índice
* [1. Instrucciones](#1-Instrucciones)
  * [1.1. Compilar el proyecto](#11-Compilar-el-proyecto)
  * [1.2. Ejecutar las pruebas](#12-Ejecutar-las-pruebas)
  * [1.3. Ejecutar el programa con Valgrind](#13-Ejecutar-el-programa-con-Valgrind)
* [2. Funcionamiento](#2-Funcionamiento)
* [3. Estructura](#3-Estructura)
  * [3.1. Diagrama de memoria](#31-Diagrama-de-memoria)
  * [3.2. Análisis de complejidades](#32-Análisis-de-complejidades)
* [4. Decisiones de diseño y/o complejidades de implementación](#4-Decisiones-de-diseño-yo-complejidades-de-implementación)
* [5. Respuestas a las preguntas teóricas](#5-Respuestas-a-las-preguntas-teóricas)

## 1. Instrucciones

### 1.1. Compilar el proyecto
```bash
make
```

### 1.2. Ejecutar las pruebas
```bash
make run
```

### 1.3. Ejecutar el programa con Valgrind
```bash
make valgrind-main
```

## 2. Funcionamiento

El Tipo de Dato Abstracto (TDA) `tp1_t` está diseñado para la gestión y consulta de registros de Pokémones. Tras la carga inicial de datos desde un archivo, el TDA expone las siguientes capacidades:

* **Búsqueda indexada:** Permite acceder a la información completa de un Pokémon específico mediante su nombre o su posición relativa en la colección (ordenada alfabéticamente).
* **Filtrado por atributos:** Posibilita la extracción de múltiples registros simultáneamente, según el tipo de pokemón solicitado.
* **Iteración interna:** Implementa un iterador (`tp1_con_cada_pokemon`) diseñado para aplicar funciones *callback* booleanas sobre los pokémones de la estructura.
* **Consulta de estado:** Provee primitivas para obtener la cantidad total de Pokémones almacenados en la estructura en todo momento.

<div align="center">
  <img src="img/diagramas/tp1_leer_archivo_2.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_leer_archivo. Es importante recalcar que al agrupar los pokémones en función de su tipo no se pierde el orden alfabético para los mismos.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_cantidad_5.svg" width="100%">
  <p><i>Diagrama de flujo tp1_cantidad.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_guardar_archivo_3.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_guardar_archivo.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_filtrar_tipo_3.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_filtrar_tipo.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_buscar_nombre_4.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_buscar_nombre.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_buscar_orden_6.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_buscar_orden.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_con_cada_pokemon_3.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_con_cada_pokemon.</i></p>
</div>
<div align="center">
  <img src="img/diagramas/tp1_destruir_4.svg" width="100%">
  <p><i>Diagrama de flujo de tp1_destruir.</i></p>
</div>


## 3. Estructura
### Arquitectura de la Estructura `tp1_t`

El Tipo de Dato Abstracto `tp1_t` está diseñado para gestionar la colección de Pokémones de manera eficiente, separando el almacenamiento de los datos de su organización lógica. La estructura se compone de los siguientes campos:

* **`pokemones_nombre`**: Un arreglo dinámico de punteros a `struct pokemon`, mediante el cual se mantiene a toda la colección ordenada alfabéticamente.
* **`pokemones_tipo`**: Un arreglo de arreglos de punteros (o matriz de referencias), donde cada sub-arreglo agrupa exclusivamente los punteros a los Pokémones correspondientes a un tipo específico de Pokémon.
* **Variables de estado (`cantidad_total` y `cant_tipos`)**: Son contadores que representan el tamaño (tope) del arreglo principal y de cada sub-arreglo por tipo, respectivamente.

#### Justificación de Diseño: Uso exclusivo de punteros
Se tomó la decisión de almacenar únicamente referencias de memoria (punteros) dentro de los arreglos de `tp1_t`, en lugar de alojar copias literales de los `struct pokemon`. Esto brinda dos ventajas fundamentales:

1. **Eficiencia temporal en el ordenamiento:** Durante la fase de carga, los datos se leen secuencialmente y luego deben ser reordenados alfabéticamente, por su nombre, y clasificados en función de su tipo. Realizar intercambios (*swaps*) utilizando únicamente punteros (cuyo tamaño es de 4 o 8 bytes como máximo, según el sistema operativo) requiere una fracción del tiempo de procesamiento en comparación con copiar y reescribir un `struct` completo de mayor tamaño.
2. **Optimización espacial e integridad de datos:** Al utilizar referencias, un mismo Pokémon puede coexistir simultáneamente en el arreglo ordenado alfabéticamente (`pokemones_nombre`) y en su respectiva categoría (`pokemones_tipo`) sin necesidad de duplicar la información del `struct` en la memoria *heap*.


### 3.1. Diagrama de memoria

<div align="center">
  <img src="img/diagramas/struct_tp1_t_9.svg" width="100%">
  <p><i>Diagrama de memoria del TDA tp1_t. Se representa aquí un escenario en el que solo se ha cargado al tp1_t un pokémon, de tipo ELEC. Aquellos punteros de los cuales no salen flechas deben ser interpretados como NULL.</i></p>
</div>


### 3.2. Análisis de complejidades temporales
Los siguientes analisis de complejidad temporal asintótica se realizan bajo la premisa de que el tamaño del problema, N ,representa siempre la cantidad de pokémones involucrados, ya sea en un archivo de entrada, dentro de la estructura `tp1_t`, o en un arreglo dinámico de punteros.

El analisis de la complejidad de la función `tp1_leer_archivo` se detalla fuera de la siguiente tabla, debido a que requiere un desglose mucho más exhaustivo en comparación con el resto de las funciones que se analizan en esta sección. 

|      Función      |Complejidad|                 Justificación                  |
|:-----------------:|:---------:|:----------------------------------------------:|
| `tp1_cantidad`       |  $O(1)$   |Independientemente de la cantidad de punteros que tengan los arreglos del `tp1_t` sacar la cantidad total es simplemente consultar el campo size_t `cantidad_total` y nada más, es decir, es de complejidad temporal asintótica constante.|
|      `tp1_buscar_orden`       |  $O(1)$   |No importa qué posición tenga el pokémon solicitado, en todos los casos hago un acceso directo a esa posición y devuelvo el valor, la complejidad temporal asintótica es constante.|
|      `tp1_destruir`       |  $O(n)$ |La complejidad temporal asintótica es lineal porque debo se recorre el arreglo, que tiene a todos los pokémones, y se los libera (liberarlos implica dos operaciones únicamente), luego a parte a parte se liberan los arreglos exclusivos de cada tipo, y eso es constante porque son siempre 8 operaciones, dado que `CANT_TIPO` vale 8.|
| `tp1_con_cada_pokemon`       |  $O(n)$   |Hago una iteración sobre el arreglo pokémones_nombre que tiene todos los pokémones, así que en el peor de los casos es justo n la cantidad de operaciones y eso se multiplica por la complejidad temporal asintótica de f, que no conozco, por ende O(n.O(f)).|
| `tp1_guardar_archivo`       |  $O(n)$   |Es un caso de uso particular para el iterador interno, que como vimos es lineal, y la función que se le aplica a cada pokémon es de escritura, es decir, de complejidad temporal asintótica constante en relación a la cantidad de pokémones, por lo tanto `tp1_t tp1_guardar_archivo` es de complejidad temporal asintótica lineal.|
| `tp1_buscar_nombre`       |  $O(log(n))$   |El algortimo que se usa para encontrar el pokémon solicitado dentro del arreglo de `pokémones_nombre` es la búsqueda binaria. La búsqueda binaria es un algortimo de divide y vencerás al que se le puede aplicar el teorema maestro, la función tiene una sola llamada recursiva por ende las llamadas no crecen a medida que se "profundiza" en los niveles del árbol de recursión, es decir, el factor de ramificación es 1, y la parte no recursiva es constante (calcular una posición y contrastar un valor con otro), por ende en todos los niveles el trabajo no solo es igual sino que es de complejidad temporal asintótica constante, y la complejidad temporal asintótica del total de la función se puede calcular con la cantidad de niveles, que se calcula con el $\log_b n$, siendo b el factor de reducción y n el tamaño del problema, ello nos da una complejidad temporal asintótica logarítmica.|
| `tp1_filtrar_tipo`       |  $O(n)$   |En esta función se realizan copias de los pokémones del arreglo exclusivo del tipo solicitado, que siempre es menor o igual al arreglo que contiene a todos los pokémones, en el peor de los casos (que justo todos los pokémones del `tp1_t` sean del tipo solicitado) la complejidad temporal asintótica es 2n, o sea, la complejidad temporal asintótica es lineal.|


#### Analisis de la complejidad de `tp1_leer_archivo`:
  Esta es la función más compleja y larga de las que se pedía implementar, por eso hago el analisis por separado, fuera de la tabla. En el peor de los casos se realizan 4 llamadas a funciones auxiliares de complejidad temporal asintótica no constante, estas son `cargar_en_bruto`, `ordenar_alfabeticamente`, `limpiar_y_contar`, y `clasificar_por_tipo`.
Prosigo con el analisis de cada una para determinar la complejidad total de la función. 

##### Analis de la complejidad de `cargar_en_bruto`:

La función ejecuta un ciclo `while` que itera $N$ veces (una vez por cada línea/Pokémon leída del archivo). En cada iteración, insertar un elemento en un arreglo, lo que implica $1$ operación. Sin embargo, cuando la capacidad del arreglo se llena, la función `agregar_pokemon` realiza un `realloc` duplicando el tamaño del buffer y copiando los elementos existentes.

Dado que las redimensiones del arreglo ocurren en potencias de 2 ($2, 4, 8, 16...$), la cantidad total de redimensiones para $N$ pokémones es $\log_2 N$. 

Aplicando el análisis de la complejidad amortizada, el costo total de todas las copias de memoria en está dado por la siguiente sumatoria:

$$\Large \text{Costo de Copias} = \sum_{i=1}^{\log_2 N} 2^i$$

Por la propiedad matemática de la suma de potencias de 2, sabemos que $\Large \sum_{i=1}^{k} 2^i = 2^{k+1} - 2$. Reemplazando obtenemos:

$$\Large \text{Costo de Copias} = 2^{(\log_2 N) + 1} - 2$$

Aplicando la propiedades de exponentes pasamos a tener ($x^{a+1} = x \cdot x^a$):

$$\Large \text{Costo de Copias} = 2 \cdot 2^{\log_2 N} - 2$$

Y por propiedades de logaritmos, sabemos que $2^{\log_2 N} = N$. Por lo tanto, la expresión queda como:

$$\Large \text{Costo de Copias} = 2N - 2$$

Para obtener el esfuerzo exacto $f(N)$ en el peor de los casos, sumamos el costo de las inserciones individuales ($N$) al costo total de las copias que acabamos de calcular y al costo de leer y parsear las lineas

$$\Large f(N) = N + (2N - 2) +2N = 5N - 2$$

Por las propiedades del análisis asintótico, sabemos que los coeficientes y los términos de menor grado no afectan la tasa de crecimiento cuando $N$ tiende a infinito. Por lo tanto, podemos afirmar que la función tiene una complejidad temporal asintótica lineal.

##### Analisis de la función `ordenar_alfabeticamente`:

La función `ordenar_alfabeticamente` actúa como punto de entrada para `merge_sort_alfabetico`, el cual implementa un algoritmo del tipo *divide y vencerás*. 

Podemos modelar su complejidad temporal $T(N)$ para un arreglo de $N$ Pokémones mediante la siguiente relación de recurrencia:

$$\Large T(N) = 2T(N/2) + O(N)$$ 

Donde:
* El término $2T(N/2)$ representa las dos llamadas recursivas, cada una procesando la mitad del arreglo.
* El término $O(N)$ representa el costo lineal de la función `merge_alfabetico`, la cual recorre y mezcla las dos mitades en un arreglo ordenado auxiliar.

Para resolver esta recurrencia, aplicamos el **Teorema Maestro**, cuya forma general es:

$$\Large T(N) = aT(N/b) + f(N)$$

Extrayendo las constantes de nuestra función, obtenemos:
* $a = 2$ (factor de ramificación)
* $b = 2$ (factor de reducción)
* $f(N) = O(N)$ (esfuerzo de mezcla)

Para determinar en qué caso del teorema nos encontramos, calculamos el polinomio crítico $N^{\log_b a}$ que representa la cantida de hojas del árbol:

$$\Large N^{\log_2 2} = N^1 = N$$

Al comparar el esfuerzo de mezcla $f(N)$ con el polinomio crítico que representa la cantidad de hojas, observamos que crecen asintóticamente a la misma velocidad (es decir, $f(N)$ es proporcional a $N^{\log_b a}$). Esto significa que estamos en el **Caso 2** del Teorema Maestro.

La resolución para el Caso 2 dicta que la complejidad temporal final se obtiene multiplicando el polinomio crítico (o el esfuerzo de mezcla, porque son equivalentes) por un factor logarítmico:

$$\Large T(N) = O(N^{\log_b a} \log_2 N)$$

Sustituyendo en nuestros valores:

$$\Large T(N) = O(N \log_2 N)$$

Aplicando el Teorema Maestro, se demostró que la complejidad temporal asintótica de `ordenar_alfabeticamente` en el peor de los casos pertenece a **$O(N \log N)$**.

#### Análisis de la función `limpiar_y_contar`

La función `limpiar_y_contar` tiene como objetivo eliminar los Pokémones duplicados y contar la distribución por tipos. Su algoritmo utiliza una técnica de "dos punteros" (`i` y `j`) para recorrer y modificar el arreglo sin utilizar arreglos auxiliares.

Para un arreglo de $N$ Pokémones, podemos dividir el análisis en dos etapas:

1. **Recorrido y limpieza:** El ciclo `while` itera a lo sumo $N$ veces. En cada iteración, realiza operaciones de reasignación de punteros, incrementos aritméticos y libera memoria (`free`), las cuales son todas $\mathcal{O}(1)$. Además, ejecuta `strcasecmp` para comparar nombres. Dado que la longitud máxima de un nombre es una constante acotada ($L$), la comparación se considera $\mathcal{O}(1)$. El costo total de este ciclo es $\mathcal{O}(N)$.
2. **Ajuste de memoria:** Al finalizar, se llama a `ajustar_buffer` (que ejecuta un `realloc`) para encoger el arreglo y liberar la memoria sobrante. En el peor de los casos, si no hubo duplicados, se copian $N$ punteros, lo que implica un esfuerzo de $\mathcal{O}(N)$.

Aplicando la regla de la suma para bloques secuenciales, la función de costo asintótico resulta:

$$\Large T(N) = \mathcal{O}(N) + \mathcal{O}(N) \in \mathcal{O}(N)$$

**Conclusión:** La complejidad temporal asintótica de `limpiar_y_contar` es estrictamente **$\mathcal{O}(N)$**.

---

#### Análisis de la función `clasificar_por_tipo`

La función `clasificar_por_tipo` distribuye los punteros de los Pokémones ya procesados en 8 arreglos secundarios según su tipo.

El algoritmo consta de dos bloques secuenciales:

1. **Reserva de Memoria:** Un bucle `for` inicial reserva la memoria exacta necesaria para cada arreglo de tipos. Como la cantidad de tipos es constante (`CANT_TIPOS = 8`) y los tamaños exactos ya fueron calculados en la función `limpiar_y_contar` (evitando tener que redimensionar los arreglos dinámicamente), este ciclo se ejecuta en tiempo constante $\mathcal{O}(1)$.
2. **Distribución de Punteros:** El segundo ciclo `for` itera exactamente $N$ veces (donde $N$ es la cantidad de Pokémones únicos restantes). En cada iteración, realiza lecturas y asignaciones de punteros mediante índices en los diferentes arreglos. El acceso directo a un arreglo en memoria tiene costo $\mathcal{O}(1)$. El esfuerzo total de este ciclo es $\mathcal{O}(N)$.

Planteando la suma de complejidades secuenciales, el término constante es absorbido por el término lineal:

$$\Large T(N) = \mathcal{O}(1) + \mathcal{O}(N) \in \mathcal{O}(N)$$

**Conclusión:** Gracias a la pre-asignación de memoria exacta, la complejidad temporal asintótica de `clasificar_por_tipo` es **$\mathcal{O}(N)$**.
 
#### Conclusión final
Dado que estas funciones se ejecutan de manera estrictamente secuencial una tras otra, el esfuerzo temporal total $T(N)$ de `tp1_leer_archivo` se representa como la suma de los esfuerzos asintóticos de sus componentes:

$$\Large T(N) = O(N) + O(N \log N) + O(N) + O(N)$$

Para simplificar esta expresión, aplicamos la Regla del Término Dominante del análisis asintótico, la cual establece que la suma de varias complejidades temporales pertenece al orden de la función con mayor tasa de crecimiento. Al comparar nuestras cotas, sabemos que el crecimiento lineal-logarítmico domina de forma estricta al crecimiento lineal cuando $N$ tiende a infinito ($N \log N > N$). Por lo tanto, los términos lineales de `cargar_en_bruto`, `limpiar_y_contar` y `clasificar_por_tipo` son absorbidos por el término dominante del ordenamiento:

$$\Large T(N) \in O(N \log N)$$

**Conclusión:** La complejidad temporal asintótica total de la función `tp1_leer_archivo` está dictada por su operación más costosa, resultando en un tiempo de ejecución de **$O(N \log N)$**.



## 4. Decisiones de diseño y/o complejidades de implementación
Se estableció que la mayor parte del procesamiento ocurra en la función `tp1_leer_archivo`, que tiene complejidad temporal asintótica $O(N)$, esta función se encarga de leer el archivo, validar las lineas, crear y cargar los struct pokémon, ordenarlos por orden alfabético, quitar los repetidos, contar los pokémones por tipo y finalmente ordenar a los pokémones por su tipo.

Para la carga en bruto de los punteros se utilizó una estrategia de expansión geométrica (complejidad amortizada), evitando así que la función principal recaiga en una complejidad temporal asintótica $O(N^2)$ por los `reallocs` excesivos, y para el orden alfabético se implementó una versión de merge sort con `strcasecmp` para la comparación de elementos; luego se ejecutan dos iteraciones distintas en arreglo que tiene a todos los pokémones, una para quitar los pokémones repetidos del arreglo y contabilizar los únicos en función de su tipo, y otra para colocar copias de los punteros en los arreglos que están dedicados a un solo tipo de pokémones.

En la función `tp1_buscar_nombre` se implementó una búsqueda binaria para hacer que la complejidad temporal asintótica de la función no fuese lineal sino logarítmica, aprovechando que en `tp1_leer_archivo` se ordenó alfabéticamente los pokémones.

Para `tp1_filtrar_tipo` se recorre únicamente el arreglo exclusivo del tipo solicitado de los pokémones del `tp1_t` fuente, y se copia la información al arreglo `pokémones_nombre` y al arreglo exclusivo del tipo solicitado del `tp1_t` destino, por último se actualiza el campo `cantidad_total` y el valor que representa la cantidad del tipo solicitado dentro del arreglo de cantidades del `tp1_t` destino.

Se decidió modularizar algunas funciones de la implementación colocándolas en `utils.h` debido a que estas funciones no están relacionadas estrictamente con el TDA `tp1_t` del trabajo práctico y/o se necesitaban en el main.c

## 5. Respuestas a las preguntas teóricas

### Consigna 1
> *"Explicar la elección de la estructura para implementar la funcionalidad pedida. Justifique el uso de cada uno de los campos de la estructura."*

📌 **Respuesta:** Esta justificación se encuentra desarrollada en detalle en la [sección 3, Estructura](#3-estructura).

---

### Consigna 2
> *"Dar una definición de complejidad computacional y explique cómo se calcula."*

#### Complejidad Computacional

En las ciencias de la computación, el término "complejidad computacional" posee una doble acepción dependiendo del contexto en el que se utilice:

* **Como campo de estudio:** Hace referencia a la *Teoría de la Complejidad Computacional*, una rama de la ciencia de la computación dedicada a entender y clasificar el "costo" intrínseco de los algoritmos y los límites teóricos de procesamiento.
* **Como propiedad de los algoritmos:** Se refiere a la característica estructural, inmutable y puramente matemática de un algoritmo específico, la cual es completamente independiente del hardware físico o del lenguaje de programación utilizado.

**Definición:**
La complejidad computacional (entendida como propiedad) expresa la cantidad de recursos que un algoritmo demanda para su ejecución en función del tamaño de la entrada de datos (denotado como $N$). Los dos recursos principales (pero no los únicos) que se analizan son el **tiempo de ejecución** (complejidad temporal, medida en operaciones elementales) y la **memoria utilizada** (complejidad espacial, medida en espacio de almacenamiento auxiliar). El objetivo es establecer el comportamiento teórico del algoritmo a medida que $N$ tiende al infinito (comportamiento asintótico). 

En la materia, de momento, solo se ha abordado la complejidad temporal, pero el método utilizado para analizar ambos tipos de complejidades es, a grandes rasgos, el mismo.

**Método de Cálculo:**
El cálculo se realiza mediante el análisis asintótico, y se expresa a través de la notación Big-O ($O$). Para determinar la complejidad de un algoritmo, se sigue un procedimiento de abstracción:

1. **Se identifica el tamaño del problema:** Se define qué variable específica representa el volumen de datos a procesar ($N$).
2. **Conteo de operaciones:** Se contabilizan las operaciones primitivas (asignaciones, comparaciones, saltos, operaciones aritméticas) que se ejecutan, asumiendo siempre el peor de los casos posibles.
3. **Identificación del término dominante:** Se formula una función matemática $f(N)$ que describe el costo total del algoritmo. De esta función, se aísla exclusivamente el término de mayor orden de crecimiento, ya que es el único que impacta de forma significativa cuando $N$ tiende a infinito.
4. **Eliminación de constantes:** Se descartan los coeficientes y las constantes aditivas, dado que la notación busca clasificar la "tasa de crecimiento" y no el costo exacto en operaciones elementales. Por ejemplo, una función de complejidad temporal $f(N) = 3N^2 + 5N + 10$ se reduce y clasifica algebraicamente bajo la complejidad asintótica $O(N^2)$.

---

### Consigna 3
> *"Explicar con diagramas cómo quedan dispuestas las estructuras y elementos en memoria."*

📌 **Respuesta:** El diagrama de memoria y su explicación se encuentran en la [sección 3.1, Diagrama de memoria](#31-diagrama-de-memoria).

---

### Consigna 4
> *"Justificar la complejidad computacional temporal de cada una de las funciones que se piden implementar."*

📌 **Respuesta:** Las justificaciones y cálculos asintóticos se detallan en la [sección 3.2, Análisis de complejidades](#32-análisis-de-complejidades).

---

### Consigna 5
> *"Explique qué dificultades tuvo para implementar las funcionalidades pedidas en el main (si tuvo alguna) y explique si alguna de estas dificultades se podría haber evitado modificando la definición del .h"*

📌 **Respuesta:** Las decisiones tomadas respecto a las funcionalidades y la necesidad de modularizar ciertas operaciones en `utils.h` se responden en la [sección 4, Decisiones de diseño y/o complejidades de implementación](#4-decisiones-de-diseño-yo-complejidades-de-implementación).
